#include "Menu.h"
#include <iostream>
#include <conio.h>
#include "Array.h"
#include "List.h"
#include "BinaryHeap.h"


std::string Menu::nazwa(int page)
{
	switch (page)
	{
	case 0:
		return "Tablica";
		break;
	case 1:
		return "Lista";
		break;
	case 2:
		return "Kopiec";
		break;
	}
}

void Menu::loop()
{
	while (exit)
	{
		this->display();
		this->input();
	}

}

void Menu::display()
{
	std::cout << "========Projekt SDiZO========" << std::endl;
	std::cout << "=========Marzec 2020=========" << std::endl;
	std::cout << "Sterowanie: a-lewo d-prawo w-gora s-dol Wyjscie-Esc" << std::endl;
	std::cout << "" << std::endl;
	std::cout << "<" << nazwa(page)<< ">" << std::endl;

	switch (this->index)
	{
	case 0:
		std::cout << "->" << "Zbuduj z Pliku (niedostepne)" << std::endl;
		std::cout << "  " << "Usun" << std::endl;
		std::cout << "  " << "Dodaj" << std::endl;
		std::cout << "  " << "Znajdz" << std::endl;
		std::cout << "  " << "Utworz losowo" << std::endl;
		std::cout << "  " << "Wyswietl" << std::endl;
		break;
	case 1:
		std::cout << "  " << "Zbuduj z Pliku (niedostepne)" << std::endl;
		std::cout << "->" << "Usun" << std::endl;
		std::cout << "  " << "Dodaj" << std::endl;
		std::cout << "  " << "Znajdz" << std::endl;
		std::cout << "  " << "Utworz losowo" << std::endl;
		std::cout << "  " << "Wyswietl" << std::endl;
		break;
	case 2:
		std::cout << "  " << "Zbuduj z Pliku (niedostepne)" << std::endl;
		std::cout << "  " << "Usun" << std::endl;
		std::cout << "->" << "Dodaj" << std::endl;
		std::cout << "  " << "Znajdz" << std::endl;
		std::cout << "  " << "Utworz losowo" << std::endl;
		std::cout << "  " << "Wyswietl" << std::endl;
		break;

	case 3:
		std::cout << "  " << "Zbuduj z Pliku (niedostepne)" << std::endl;
		std::cout << "  " << "Usun" << std::endl;
		std::cout << "  " << "Dodaj" << std::endl;
		std::cout << "->" << "Znajdz" << std::endl;
		std::cout << "  " << "Utworz losowo" << std::endl;
		std::cout << "  " << "Wyswietl" << std::endl;
		break;
	case 4:
		std::cout << "  " << "Zbuduj z Pliku (niedostepne)" << std::endl;
		std::cout << "  " << "Usun" << std::endl;
		std::cout << "  " << "Dodaj" << std::endl;
		std::cout << "  " << "Znajdz" << std::endl;
		std::cout << "->" << "Utworz losowo" << std::endl;
		std::cout << "  " << "Wyswietl" << std::endl;
		break;
	case 5:
		std::cout << "  " << "Zbuduj z Pliku (niedostepne)" << std::endl;
		std::cout << "  " << "Usun" << std::endl;
		std::cout << "  " << "Dodaj" << std::endl;
		std::cout << "  " << "Znajdz" << std::endl;
		std::cout << "  " << "Utworz losowo" << std::endl;
		std::cout << "->" << "Wyswietl" << std::endl;
		break;
	}


}

void Menu::input()
{	
	char i = _getch();
	switch (i)
	{
	case 'a':
		if (this->page == 0)
		{
			this->page = SIZEX;
		}
		else
		{
			this->page--;
		}
		break;
	case 'd':
		if (this->page == SIZEX)
		{
			this->page = 0;
		}
		else
		{
			this->page++;
		}
		break;
	case 'w':
		if (this->index == 0)
		{
			this->index = SIZEY;
		}
		else
		{
			this->index--;
		}
		break;
	case 's':
		if (this->index == SIZEY)
		{
			this->index = 0;
		}
		else
		{
			this->index++;
		}
		break;
	case 13:
		switch (this->page)
		{
			int i;
		case 0:
			switch (this->index)
			{
			case 0:
				break;
			case 1:
				std::cout << "Podaj index do usuniecia:";
				std::cin >> i;
				this->array->pop(i);
				break;
			case 2:
				size_t j;
				std::cout << "Podaj index do na ktory chcesz dodac:";
				std::cin >> j;
				std::cout << "Podaj wartosc:";
				std::cin >> i;
				this->array->push(i, j);
				break;
			case 3:
				std::cout << "Podaj liczbe do znalezienia:";
				std::cin >> i;
				if (this->array->search(i))std::cout << "Znaleziono";
				else std::cout << "Nie znaleziono";
				_getch();
				break;
			case 4:
				break;
			case 5:
				this->array->display();
				_getch();
				break;
			}
			break;
		case 1:
			switch (this->index)
			{
			case 0:
				break;
			case 1:
				std::cout << "Podaj index do usuniecia:";
				std::cin >> i;
				this->list->pop(i);
				break;
			case 2:
				size_t j;
				std::cout << "Podaj index do na ktory chcesz dodac:";
				std::cin >> j;
				std::cout << "Podaj wartosc:";
				std::cin >> i;
				this->list->push(i, j);
				break;
			case 3:
				std::cout << "Podaj liczbe do znalezienia:";
				std::cin >> i;
				if (this->list->search(i))std::cout << "Znaleziono";
				else std::cout << "Nie znaleziono";
				_getch();
				break;
			case 4:
				break;
			case 5:
				this->list->display();
				_getch();
				break;
			}
			break;
		case 2:
			switch (this->index)
			{
			case 0:
				break;
			case 1:
				break;
			case 2:
				break;
			case 3:
				break;
			case 4:
				break;
			case 5:
				break;
			}
			break;
		}
		break;
	case 27:
		_exit(0);
		break;
	}
	system("cls");
}

Menu::Menu()
{
	this->array = new Array();
	this->list = new List();
	this->heap = new BinaryHeap();	
	this->loop();
}

Menu::~Menu()
{

}
