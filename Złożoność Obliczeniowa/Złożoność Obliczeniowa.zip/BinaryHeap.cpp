#include "BinaryHeap.h"
#include <iostream>


size_t BinaryHeap::parentIndex(int index)
{	
	return (index-1)/2;
}

size_t BinaryHeap::childLeftIndex(int index)
{
	return 2*index+1;
}

size_t BinaryHeap::childRightIndex(int index)
{
	return 2*index+2;
}

void BinaryHeap::fixDown(int index)
{
	while (this->tab[this->childLeftIndex(index)] > this->tab[index] || this->tab[this->childRightIndex(index)] > this->tab[index])
	{
		std::cout << "a";
		if (this->tab[this->childLeftIndex(index)] > this->tab[this->childRightIndex(index)])
		{
			int temp = tab[this->childLeftIndex(index)];
			this->tab[this->childLeftIndex(index)] = tab[index];
			this->tab[index] = temp;
			index = this->childLeftIndex(index);
		}
		else
		{
			int temp = tab[this->childRightIndex(index)];
			this->tab[this->childRightIndex(index)] = this->tab[index];
			this->tab[index] = temp;
			index = this->childRightIndex(index);
		}
	}
}

void BinaryHeap::fixUp(int index)
{
	while (this->tab[parentIndex(index)] < this->tab[index])
	{
		int temp = tab[this->parentIndex(index)];
		this->tab[this->parentIndex(index)] = this->tab[index];
		this->tab[index] = temp;
		index = this->parentIndex(index);
	}
}

void BinaryHeap::push(int value)
{
	int i = this->size;
	this->tab[this->size] = value;
	this->size++;
	while (i != 0 && this->tab[parentIndex(i)] < this->tab[i])
	{
		int temp = this->tab[this->parentIndex(i)];
		this->tab[this->parentIndex(i)] = this->tab[i];
		this->tab[i] = temp;
		i = this->parentIndex(i);
	}
}

void BinaryHeap::pop(int index)
{
	this->tab[index] = this->tab[size - 1];
	this->size--;
	fixDown(index);
}

void BinaryHeap::add(int value)
{
	this->tab[size] = value;
	size++;
}

void BinaryHeap::displayTable()
{
	for (int i = 0;i < size;i++)
	{
		std::cout << tab[i] << " ";
	}
}



BinaryHeap::BinaryHeap()
{
	this->tab = new int[SIZEMAX];
	this->size = 0;
}

BinaryHeap::~BinaryHeap()
{
	delete[] this->tab;
}
