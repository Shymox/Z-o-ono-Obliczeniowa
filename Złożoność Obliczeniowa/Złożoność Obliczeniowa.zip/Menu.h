#pragma once
#include <string>
#include <string>
#include "Array.h"
#include "List.h"
#include "BinaryHeap.h"
class Menu
{
private:
	int page=0;
	int index=0;
	bool exit = true;
	const int SIZEX = 2;
	const int SIZEY = 5;
	std::string nazwa(int page);
	Array* array;
	List* list;
	BinaryHeap* heap;

public:
	void loop();

	void display();

	void input();

	Menu();

	~Menu();
};

