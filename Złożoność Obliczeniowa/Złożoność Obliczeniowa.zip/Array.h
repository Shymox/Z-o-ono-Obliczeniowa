#pragma once
class Array
{
private:
	int* array;
	size_t size;
public:

	void pushFront(int value);

	void pushBack(int value);

	void push(int value, size_t index);

	void popFront();

	void popBack();

	void pop(int index);

	bool search(int number);

	size_t length();

	void display();
	Array();

	~Array();

};

