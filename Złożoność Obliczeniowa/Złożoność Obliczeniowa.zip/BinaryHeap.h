#pragma once
class BinaryHeap
{
private:
	const size_t SIZEMAX = 20000;

	size_t size;

	int* tab;

	size_t parentIndex(int index);

	size_t childLeftIndex(int index);

	size_t childRightIndex(int index);
public:
	void fixDown(int index);

	void fixUp(int index);

	void push(int value);

	void pop(int index);

	void add(int value);

	void displayTable();

	BinaryHeap();

	~BinaryHeap();
};


